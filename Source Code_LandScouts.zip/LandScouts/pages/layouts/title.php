<title>LandScout </title>
<link rel="icon" type="image/x-icon" href="/<?= $project_name?>/images/logo.png">